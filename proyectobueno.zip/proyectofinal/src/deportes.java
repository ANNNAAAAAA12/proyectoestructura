
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Gyrcpro
 */
public class deportes extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(deportes.class.getName());

    /**
     * Creates new form deportes
     */
    public deportes() {
        initComponents();
        //colores paneles
        deport.setBackground(new java.awt.Color(144,236,230));
        panel1.setBackground(new java.awt.Color(173, 216, 230));
        
        panel2.setBackground(new java.awt.Color(144, 238, 144));
        
        panel3.setBackground(new java.awt.Color(173, 216, 230));
        

        panel4.setBackground(new java.awt.Color(173, 216, 230));

        panel5.setBackground(new java.awt.Color(173, 216, 230));


        //botones funcion
         lugaresboton.addActionListener((ActionEvent e) -> {
    lugares ventanaLugares = new lugares();
    ventanaLugares.setVisible(true);
    dispose(); // Cierra la ventana actual
});
         apunabboton.addActionListener((ActionEvent e) -> {
    apunab ventanaApunab = new apunab();
    ventanaApunab.setVisible(true);
    dispose(); // Cierra la ventana actual
});
         inicioboton.addActionListener((ActionEvent e) -> {
    inicio ventanaInicio = new inicio();
    ventanaInicio.setVisible(true);
    dispose(); // Cierra la ventana actual
});
         jButton1.addActionListener(e -> {
    VER ventanaVER = new VER();
    ventanaVER.setVisible(true);
    dispose();
});
         estudiantesboton.addActionListener((ActionEvent e) -> {
    estudiantes ventanaEstudiantes = new estudiantes();
    ventanaEstudiantes.setVisible(true);
    dispose(); // Cierra la ventana actual
});
         //basicooooo
        getContentPane().setBackground(new java.awt.Color(106, 214, 218)); 
         panelarriba.setBackground(new java.awt.Color(15, 175, 255));
         panelabajo.setBackground(new java.awt.Color(114, 133, 140));
         //logoarribahp
        ImageIcon originalIcon = new ImageIcon(getClass().getResource("logo.png"));
Image originalImage = originalIcon.getImage();
Image imagenEscalada = originalImage.getScaledInstance(200, 120, Image.SCALE_SMOOTH);
ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
logo = new javax.swing.JLabel(iconoEscalado);
//logoabajo
 ImageIcon originalIcon1 = new ImageIcon(getClass().getResource("logo2.png"));
Image originalImage1 = originalIcon1.getImage();

int nuevoAncho1 = 100;
int nuevoAlto1 = 100;
Image imagenEscalada1 = originalImage1.getScaledInstance(nuevoAncho1, nuevoAlto1, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado1 = new ImageIcon(imagenEscalada1);
logo3 = new javax.swing.JLabel(iconoEscalado1);

panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
panelabajo.add(logo3);
TEXTOO.setForeground(Color.WHITE);


//demaslogoarriba
lugaresboton.setBackground(new java.awt.Color(15,175,255));
        estudiantesboton.setBackground(new java.awt.Color(15, 175, 255));
        inicioboton.setBackground(new java.awt.Color(15, 175, 255));
        apunabboton.setBackground(new java.awt.Color(15, 175, 255));
        lugaresboton.setBorder(BorderFactory.createEmptyBorder());
        estudiantesboton.setBorder(BorderFactory.createEmptyBorder());
        inicioboton.setBorder(BorderFactory.createEmptyBorder());
        apunabboton.setBorder(BorderFactory.createEmptyBorder());
        lugaresboton.setForeground(Color.WHITE);
        estudiantesboton.setForeground(Color.WHITE);
        inicioboton.setForeground(Color.WHITE);
        apunabboton.setForeground(Color.WHITE);
         lugaresboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         estudiantesboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         inicioboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         apunabboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
JPanel panelBotones = new JPanel();
panelBotones.setBackground(new java.awt.Color(15, 175, 255)); // Igual que panelarriba
panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
panelBotones.setOpaque(false); // Asegura que no sobrescriba el fondo si hay algún error

// botones
panelBotones.add(Box.createHorizontalGlue());
panelBotones.add(lugaresboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(inicioboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(estudiantesboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(apunabboton);
panelBotones.add(Box.createHorizontalGlue());

// panelarriba organizado con BorderLayout
panelarriba.setLayout(new BorderLayout());
panelarriba.removeAll(); // Limpiar 
panelarriba.add(logo, BorderLayout.WEST);          // Logo a la izquierda
panelarriba.add(panelBotones, BorderLayout.CENTER); // Botones centrados
panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT)); 
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jMenu2 = new javax.swing.JMenu();
        panelarriba = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        lugaresboton = new javax.swing.JButton();
        inicioboton = new javax.swing.JButton();
        estudiantesboton = new javax.swing.JButton();
        apunabboton = new javax.swing.JButton();
        panelabajo = new javax.swing.JPanel();
        TEXTOO = new javax.swing.JLabel();
        logo3 = new javax.swing.JLabel();
        deport = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        panel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        panel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        panel3 = new javax.swing.JLabel();
        panel4 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        panel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        jMenu1.setText("jMenu1");

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        jMenu2.setText("jMenu2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lugaresboton.setText("lugares");
        lugaresboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lugaresbotonActionPerformed(evt);
            }
        });

        inicioboton.setText("inicio");
        inicioboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniciobotonActionPerformed(evt);
            }
        });

        estudiantesboton.setText("estudiantes");
        estudiantesboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estudiantesbotonActionPerformed(evt);
            }
        });

        apunabboton.setText("mis APUNAB");
        apunabboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apunabbotonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelarribaLayout = new javax.swing.GroupLayout(panelarriba);
        panelarriba.setLayout(panelarribaLayout);
        panelarribaLayout.setHorizontalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lugaresboton)
                .addGap(126, 126, 126)
                .addComponent(inicioboton)
                .addGap(103, 103, 103)
                .addComponent(estudiantesboton)
                .addGap(71, 71, 71)
                .addComponent(apunabboton)
                .addGap(42, 42, 42))
        );
        panelarribaLayout.setVerticalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelarribaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lugaresboton)
                    .addComponent(inicioboton)
                    .addComponent(estudiantesboton)
                    .addComponent(apunabboton))
                .addGap(50, 50, 50))
        );

        TEXTOO.setForeground(new java.awt.Color(18, 20, 9));
        TEXTOO.setText("ónoma de Bucaramanga, con domicilio en la ciudad de Bucaramanga, por 6 años. | Avenida 42 No. 48 – 11, Bucaramanga – Colombia. | PBX (57) (7) 643 6111/643 6261 | Cent");
        TEXTOO.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        TEXTOO.setAutoscrolls(true);

        javax.swing.GroupLayout panelabajoLayout = new javax.swing.GroupLayout(panelabajo);
        panelabajo.setLayout(panelabajoLayout);
        panelabajoLayout.setHorizontalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TEXTOO, javax.swing.GroupLayout.PREFERRED_SIZE, 918, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(logo3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(84, Short.MAX_VALUE))
        );
        panelabajoLayout.setVerticalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addComponent(logo3, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(TEXTOO)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        deport.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        deport.setForeground(new java.awt.Color(0, 35, 102));
        deport.setText("DEPORTES");

        jButton1.setText("VER");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 35, 102));
        jLabel6.setText("partidos en tendencia  🔥​                     todos los partidos                                 jugadores           ");

        javax.swing.GroupLayout panel1Layout = new javax.swing.GroupLayout(panel1);
        panel1.setLayout(panel1Layout);
        panel1Layout.setHorizontalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        panel1Layout.setVerticalGroup(
            panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel6)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        panel2.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        panel2.setForeground(new java.awt.Color(0, 35, 102));
        panel2.setText("partidos en tendencia  🔥​                     todos los partidos                                 jugadores           ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(panel2)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(panel2)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        panel3.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        panel3.setForeground(new java.awt.Color(0, 35, 102));
        panel3.setText("partidos en tendencia  🔥​                     todos los partidos                                 jugadores           ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(panel3)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(panel3)
                .addGap(28, 28, 28))
        );

        jLabel12.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 35, 102));
        jLabel12.setText("partidos en tendencia  🔥​                     todos los partidos                                 jugadores           ");

        javax.swing.GroupLayout panel4Layout = new javax.swing.GroupLayout(panel4);
        panel4.setLayout(panel4Layout);
        panel4Layout.setHorizontalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel12)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        panel4Layout.setVerticalGroup(
            panel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel4Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel12)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 35, 102));
        jLabel2.setText("Fútbol  ⚽");

        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 35, 102));
        jLabel3.setText("Tenis 🥎​");

        jLabel4.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 35, 102));
        jLabel4.setText("Volley 🏐​");

        jLabel5.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 35, 102));
        jLabel5.setText("Basket 🏀​");

        javax.swing.GroupLayout panel5Layout = new javax.swing.GroupLayout(panel5);
        panel5.setLayout(panel5Layout);
        panel5Layout.setHorizontalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel5Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addContainerGap(52, Short.MAX_VALUE))
        );
        panel5Layout.setVerticalGroup(
            panel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panel5Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel2)
                .addGap(61, 61, 61)
                .addComponent(jLabel3)
                .addGap(71, 71, 71)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(29, 29, 29))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelarriba, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelabajo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(473, 473, 473)
                .addComponent(deport)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(panel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelarriba, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(deport, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(103, 103, 103)
                                .addComponent(panel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(131, 131, 131)
                                .addComponent(jButton1)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(panel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(111, 111, 111)
                        .addComponent(panel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(panelabajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lugaresbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lugaresbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lugaresbotonActionPerformed

    private void iniciobotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniciobotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iniciobotonActionPerformed

    private void estudiantesbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estudiantesbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_estudiantesbotonActionPerformed

    private void apunabbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apunabbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apunabbotonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new deportes().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TEXTOO;
    private javax.swing.JButton apunabboton;
    private javax.swing.JLabel deport;
    private javax.swing.JButton estudiantesboton;
    private javax.swing.JButton inicioboton;
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel logo3;
    private javax.swing.JButton lugaresboton;
    private javax.swing.JPanel panel1;
    private javax.swing.JLabel panel2;
    private javax.swing.JLabel panel3;
    private javax.swing.JPanel panel4;
    private javax.swing.JPanel panel5;
    private javax.swing.JPanel panelabajo;
    private javax.swing.JPanel panelarriba;
    // End of variables declaration//GEN-END:variables
}
