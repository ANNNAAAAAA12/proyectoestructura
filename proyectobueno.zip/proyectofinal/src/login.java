
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author Gyrcpro
 */
public class login extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(login.class.getName());
private boolean existeUsuario(String usuario) { //metodos para manejar la persistencia
    try (BufferedReader br = new BufferedReader(new FileReader("usuarios.txt"))) {//lee el archivo
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] datos = linea.split(",");
            if (datos.length > 0 && datos[0].equalsIgnoreCase(usuario)) {
                return true;
            }
        }
    } catch (IOException e) {
        // archivo no existe o error al leer, se considera que no existe usuario
    }
    return false;
}

private void guardarUsuario(String usuario, String contrasena) throws IOException {
    try (BufferedWriter bw = new BufferedWriter(new FileWriter("usuarios.txt", true))) {
        bw.write(usuario + "," + contrasena);
        bw.newLine();
    }
}
    /**
     * Creates new form login
     */
    public login() {
        initComponents();
        //logoabajo
        ImageIcon originalIcon1 = new ImageIcon(getClass().getResource("logo2.png"));
Image originalImage1 = originalIcon1.getImage();

int nuevoAncho1 = 100;
int nuevoAlto1 = 100;
Image imagenEscalada1 = originalImage1.getScaledInstance(nuevoAncho1, nuevoAlto1, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado1 = new ImageIcon(imagenEscalada1);
logo3 = new javax.swing.JLabel(iconoEscalado1);

panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
panelabajo.add(logo3);




        
        TEXTOO.setForeground(Color.WHITE);
        
        //persistencia boton guardar
        jButton1.addActionListener(e -> {
    String usuarioIngresado = usuario.getText().trim();
    String contrasenaIngresada = new String(contraseña.getPassword()).trim();

    if (usuarioIngresado.isEmpty() || contrasenaIngresada.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.");
        return;
    }

    if (existeUsuario(usuarioIngresado)) {
        JOptionPane.showMessageDialog(this, "El usuario ya existe.");
        return;
    }

    try {
        guardarUsuario(usuarioIngresado, contrasenaIngresada);
        JOptionPane.showMessageDialog(this, "Usuario guardado correctamente.");
        usuario.setText("");
        contraseña.setText("");
    } catch (IOException ex) {
        JOptionPane.showMessageDialog(this, "Error al guardar usuario: " + ex.getMessage());
    }
});
        //colores y fuentes
         getContentPane().setBackground(new java.awt.Color(106, 214, 218)); 
         panelarriba.setBackground(new java.awt.Color(15, 175, 255));
         panelabajo.setBackground(new java.awt.Color(114, 133, 140));
         cuadrologin.setBackground(new java.awt.Color(77, 140, 137));
         casinub.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
    casinub.setForeground(Color.WHITE);
    
    casinub.setOpaque(false);
    casinub.setBackground(new Color(0, 0, 0, 0));
    
   
    usuariotexto.setBorder(BorderFactory.createEmptyBorder());
    usuariotexto.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
    usuariotexto.setForeground(Color.WHITE);
    
    usuariotexto.setOpaque(false);
    usuariotexto.setBackground(new Color(0, 0, 0, 0));
    
    
   
    usuariotexto.setBorder(BorderFactory.createEmptyBorder());
    contraseñatexto.setBorder(BorderFactory.createEmptyBorder());
    contraseñatexto.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
    contraseñatexto.setForeground(Color.WHITE);
    
    contraseñatexto.setOpaque(false);
    contraseñatexto.setBackground(new Color(0, 0, 0, 0));
    contraseñatexto.setBorder(BorderFactory.createEmptyBorder());
    usuario.setBorder(BorderFactory.createEmptyBorder());
    usuario.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
    usuario.setForeground(Color.WHITE);
    
    usuario.setOpaque(false);
    usuario.setBackground(new Color(0, 0, 0, 0));
    contraseña.setBorder(BorderFactory.createEmptyBorder());
    contraseña.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
    contraseña.setForeground(Color.WHITE);
    
    contraseña.setOpaque(false);
    contraseña.setBackground(new Color(0, 0, 0, 0));
    
    
   
   
    casinub.setBorder(BorderFactory.createEmptyBorder());
    //logoarriba
         ImageIcon originalIcon = new ImageIcon(getClass().getResource("logo.png"));
         Image originalImage = originalIcon.getImage();


int nuevoAncho = 200; 
int nuevoAlto = 120;
Image imagenEscalada = originalImage.getScaledInstance(nuevoAncho, nuevoAlto, Image.SCALE_SMOOTH);
ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);

logo = new javax.swing.JLabel(iconoEscalado);
panelarriba.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
panelarriba.add(logo);

//boton ingresar
ingresar.addActionListener((ActionEvent e) -> {

    inicio ventanaInicio = new inicio();
    
    
    ventanaInicio.setVisible(true);

    dispose(); 
        });

   


    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelarriba = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        cuadrologin = new javax.swing.JPanel();
        casinub = new javax.swing.JTextField();
        usuario = new javax.swing.JTextField();
        contraseñatexto = new javax.swing.JTextField();
        usuariotexto = new javax.swing.JTextField();
        contraseña = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        ingresar = new javax.swing.JButton();
        panelabajo = new javax.swing.JPanel();
        TEXTOO = new javax.swing.JLabel();
        logo3 = new javax.swing.JLabel();
        logo2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout panelarribaLayout = new javax.swing.GroupLayout(panelarriba);
        panelarriba.setLayout(panelarribaLayout);
        panelarribaLayout.setHorizontalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        panelarribaLayout.setVerticalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                .addContainerGap())
        );

        casinub.setText("CASINUB");
        casinub.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                casinubActionPerformed(evt);
            }
        });

        usuario.setText("ingresa aca ");
        usuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuarioActionPerformed(evt);
            }
        });

        contraseñatexto.setText("contraseña");
        contraseñatexto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contraseñatextoActionPerformed(evt);
            }
        });

        usuariotexto.setText("usuario");
        usuariotexto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usuariotextoActionPerformed(evt);
            }
        });

        contraseña.setText("jPasswordField1");

        jButton1.setText("guardar");

        ingresar.setText("ingresar");
        ingresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ingresarMouseClicked(evt);
            }
        });
        ingresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ingresarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout cuadrologinLayout = new javax.swing.GroupLayout(cuadrologin);
        cuadrologin.setLayout(cuadrologinLayout);
        cuadrologinLayout.setHorizontalGroup(
            cuadrologinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cuadrologinLayout.createSequentialGroup()
                .addGroup(cuadrologinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(cuadrologinLayout.createSequentialGroup()
                        .addGap(112, 112, 112)
                        .addGroup(cuadrologinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(contraseñatexto, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
                            .addComponent(usuariotexto))
                        .addGap(77, 77, 77)
                        .addGroup(cuadrologinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(usuario, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(cuadrologinLayout.createSequentialGroup()
                        .addGap(236, 236, 236)
                        .addComponent(casinub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(cuadrologinLayout.createSequentialGroup()
                        .addGap(166, 166, 166)
                        .addComponent(jButton1)
                        .addGap(31, 31, 31)
                        .addComponent(ingresar)))
                .addContainerGap(126, Short.MAX_VALUE))
        );
        cuadrologinLayout.setVerticalGroup(
            cuadrologinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cuadrologinLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(casinub, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(cuadrologinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(usuario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(usuariotexto, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(cuadrologinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(contraseñatexto, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(contraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(cuadrologinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(ingresar))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        TEXTOO.setForeground(new java.awt.Color(18, 20, 9));
        TEXTOO.setText("ónoma de Bucaramanga, con domicilio en la ciudad de Bucaramanga, por 6 años. | Avenida 42 No. 48 – 11, Bucaramanga – Colombia. | PBX (57) (7) 643 6111/643 6261 | Cent");
        TEXTOO.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        TEXTOO.setAutoscrolls(true);

        javax.swing.GroupLayout panelabajoLayout = new javax.swing.GroupLayout(panelabajo);
        panelabajo.setLayout(panelabajoLayout);
        panelabajoLayout.setHorizontalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TEXTOO, javax.swing.GroupLayout.PREFERRED_SIZE, 918, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(logo3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        panelabajoLayout.setVerticalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addComponent(logo3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelabajoLayout.createSequentialGroup()
                .addGap(0, 59, Short.MAX_VALUE)
                .addComponent(TEXTOO)
                .addGap(56, 56, 56))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelarriba, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(258, 258, 258)
                .addComponent(cuadrologin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logo2, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61))
            .addComponent(panelabajo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelarriba, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(cuadrologin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(logo2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(120, 120, 120)))
                .addComponent(panelabajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void casinubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_casinubActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_casinubActionPerformed

    private void usuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usuarioActionPerformed

    private void contraseñatextoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contraseñatextoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contraseñatextoActionPerformed

    private void usuariotextoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usuariotextoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usuariotextoActionPerformed

    private void ingresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ingresarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ingresarActionPerformed

    private void ingresarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ingresarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_ingresarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new login().setVisible(true));
    }
   
    
    
    



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TEXTOO;
    private javax.swing.JTextField casinub;
    private javax.swing.JPasswordField contraseña;
    private javax.swing.JTextField contraseñatexto;
    private javax.swing.JPanel cuadrologin;
    private javax.swing.JButton ingresar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel logo2;
    private javax.swing.JLabel logo3;
    private javax.swing.JPanel panelabajo;
    private javax.swing.JPanel panelarriba;
    private javax.swing.JTextField usuario;
    private javax.swing.JTextField usuariotexto;
    // End of variables declaration//GEN-END:variables
   
}
