
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Gyrcpro
 */
public class apunab extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(apunab.class.getName());

    /**
     * Creates new form apunab
     */
    public apunab() {
        initComponents();
        //mifoto
        ImageIcon originalIcon3 = new ImageIcon(getClass().getResource("yo.png"));
Image originalImage3 = originalIcon3.getImage();

int nuevoAncho3 = 300;
int nuevoAlto3= 300;
Image imagenEscalada3 = originalImage3.getScaledInstance(nuevoAncho3, nuevoAlto3, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado3 = new ImageIcon(imagenEscalada3);
yo = new javax.swing.JLabel(iconoEscalado3);

yopanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));
yopanel.add(yo);
//botones
inicioboton2.addActionListener((ActionEvent e) -> {
    inicio ventanaInicio = new inicio();
    ventanaInicio.setVisible(true);
    dispose(); // Cierra la ventana actual
});
        deportesboton.addActionListener((ActionEvent e) -> {
    deportes ventanaDeportes = new deportes(); // Instanciar la ventana
    ventanaDeportes.setVisible(true);          // Mostrarla
    dispose();                                 // Cerrar la actual
});
        estudiantesboton.addActionListener((ActionEvent e) -> {
    estudiantes ventanaEstudiantes = new estudiantes();
    ventanaEstudiantes.setVisible(true);
    dispose(); // Cierra la ventana actual
});
 lugaresboton.addActionListener((ActionEvent e) -> {
    lugares ventanaLugares = new lugares();
    ventanaLugares.setVisible(true);
    dispose(); // Cierra la ventana actual
});
        getContentPane().setBackground(new java.awt.Color(106, 214, 218)); 
         panelarriba.setBackground(new java.awt.Color(15, 175, 255));
         panelabajo.setBackground(new java.awt.Color(114, 133, 140));
         //logoarribahp
        ImageIcon originalIcon = new ImageIcon(getClass().getResource("logo.png"));
Image originalImage = originalIcon.getImage();
Image imagenEscalada = originalImage.getScaledInstance(200, 120, Image.SCALE_SMOOTH);
ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
logo = new javax.swing.JLabel(iconoEscalado);
//logoabajo
 ImageIcon originalIcon1 = new ImageIcon(getClass().getResource("logo2.png"));
Image originalImage1 = originalIcon1.getImage();

int nuevoAncho1 = 100;
int nuevoAlto1 = 100;
Image imagenEscalada1 = originalImage1.getScaledInstance(nuevoAncho1, nuevoAlto1, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado1 = new ImageIcon(imagenEscalada1);
logo3 = new javax.swing.JLabel(iconoEscalado1);

panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
panelabajo.add(logo3);
TEXTOO.setForeground(Color.WHITE);
//insertar ruleta
RuletaPanel ruleta = new RuletaPanel();
ruleta.setBounds(400, 200, 200, 200); // Ubicación y tamaño dentro del frame
ruleta.setOpaque(false); // Si quieres fondo transparente
getContentPane().setLayout(null); // Para usar setBounds directamente
getContentPane().add(ruleta);


//demaslogoarriba
lugaresboton.setBackground(new java.awt.Color(15,175,255));
        estudiantesboton.setBackground(new java.awt.Color(15, 175, 255));
        inicioboton2.setBackground(new java.awt.Color(15, 175, 255));
        deportesboton.setBackground(new java.awt.Color(15, 175, 255));
        lugaresboton.setBorder(BorderFactory.createEmptyBorder());
        estudiantesboton.setBorder(BorderFactory.createEmptyBorder());
        inicioboton2.setBorder(BorderFactory.createEmptyBorder());
        deportesboton.setBorder(BorderFactory.createEmptyBorder());
        lugaresboton.setForeground(Color.WHITE);
        estudiantesboton.setForeground(Color.WHITE);
        inicioboton2.setForeground(Color.WHITE);
        deportesboton.setForeground(Color.WHITE);
         lugaresboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         estudiantesboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         inicioboton2.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         deportesboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
JPanel panelBotones = new JPanel();
panelBotones.setBackground(new java.awt.Color(15, 175, 255)); // Igual que panelarriba
panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
panelBotones.setOpaque(false); // Asegura que no sobrescriba el fondo si hay algún error

//CAMBIARCOLOR
GANADAS.setForeground(new Color(255, 0, 0));
PERDIDAS.setForeground(new Color(65, 105, 225));
// botones
panelBotones.add(Box.createHorizontalGlue());
panelBotones.add(lugaresboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(inicioboton2);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(estudiantesboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(deportesboton);
panelBotones.add(Box.createHorizontalGlue());

// panelarriba organizado con BorderLayout
panelarriba.setLayout(new BorderLayout());
panelarriba.removeAll(); // Limpiar 
panelarriba.add(logo, BorderLayout.WEST);          // Logo a la izquierda
panelarriba.add(panelBotones, BorderLayout.CENTER); // Botones centrados
panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT)); 
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelabajo = new javax.swing.JPanel();
        TEXTOO = new javax.swing.JLabel();
        logo3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        panelarriba = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        lugaresboton = new javax.swing.JButton();
        inicioboton2 = new javax.swing.JButton();
        deportesboton = new javax.swing.JButton();
        estudiantesboton = new javax.swing.JButton();
        panelabajo1 = new javax.swing.JPanel();
        TEXTOO1 = new javax.swing.JLabel();
        logo4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        GANADAS = new javax.swing.JLabel();
        PERDIDAS = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        infopanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        yopanel = new javax.swing.JPanel();
        yo = new javax.swing.JLabel();

        TEXTOO.setForeground(new java.awt.Color(18, 20, 9));
        TEXTOO.setText("ónoma de Bucaramanga, con domicilio en la ciudad de Bucaramanga, por 6 años. | Avenida 42 No. 48 – 11, Bucaramanga – Colombia. | PBX (57) (7) 643 6111/643 6261 | Cent");
        TEXTOO.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        TEXTOO.setAutoscrolls(true);

        javax.swing.GroupLayout panelabajoLayout = new javax.swing.GroupLayout(panelabajo);
        panelabajo.setLayout(panelabajoLayout);
        panelabajoLayout.setHorizontalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TEXTOO, javax.swing.GroupLayout.PREFERRED_SIZE, 918, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(logo3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelabajoLayout.setVerticalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addComponent(logo3, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(TEXTOO)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 35, 102));
        jLabel2.setText("ESTUDIANTES");

        jLabel11.setText("ID: U00178255");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lugaresboton.setText("lugares");
        lugaresboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lugaresbotonActionPerformed(evt);
            }
        });

        inicioboton2.setText("inicio");
        inicioboton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioboton2ActionPerformed(evt);
            }
        });

        deportesboton.setText("deportes");
        deportesboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deportesbotonActionPerformed(evt);
            }
        });

        estudiantesboton.setText("estudiantes");
        estudiantesboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estudiantesbotonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelarribaLayout = new javax.swing.GroupLayout(panelarriba);
        panelarriba.setLayout(panelarribaLayout);
        panelarribaLayout.setHorizontalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 136, Short.MAX_VALUE)
                .addComponent(lugaresboton)
                .addGap(79, 79, 79)
                .addComponent(inicioboton2)
                .addGap(89, 89, 89)
                .addComponent(deportesboton)
                .addGap(70, 70, 70)
                .addComponent(estudiantesboton)
                .addGap(202, 202, 202))
        );
        panelarribaLayout.setVerticalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelarribaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lugaresboton)
                    .addComponent(inicioboton2)
                    .addComponent(deportesboton)
                    .addComponent(estudiantesboton))
                .addGap(50, 50, 50))
        );

        TEXTOO1.setForeground(new java.awt.Color(18, 20, 9));
        TEXTOO1.setText("ónoma de Bucaramanga, con domicilio en la ciudad de Bucaramanga, por 6 años. | Avenida 42 No. 48 – 11, Bucaramanga – Colombia. | PBX (57) (7) 643 6111/643 6261 | Cent");
        TEXTOO1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        TEXTOO1.setAutoscrolls(true);

        javax.swing.GroupLayout panelabajo1Layout = new javax.swing.GroupLayout(panelabajo1);
        panelabajo1.setLayout(panelabajo1Layout);
        panelabajo1Layout.setHorizontalGroup(
            panelabajo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajo1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TEXTOO1, javax.swing.GroupLayout.PREFERRED_SIZE, 918, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(logo4, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelabajo1Layout.setVerticalGroup(
            panelabajo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajo1Layout.createSequentialGroup()
                .addComponent(logo4, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelabajo1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(TEXTOO1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 35, 102));
        jLabel3.setText("mis APUNAB");

        GANADAS.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        GANADAS.setForeground(new java.awt.Color(0, 35, 102));
        GANADAS.setText("GANADAS");

        PERDIDAS.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        PERDIDAS.setForeground(new java.awt.Color(0, 35, 102));
        PERDIDAS.setText("PERDIDAS");

        jLabel6.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 35, 102));
        jLabel6.setText("21/04/2025  Ana Mendez  vs Eliana Perez --→  Squash --→ 3-4");

        jLabel7.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 35, 102));
        jLabel7.setText("4/03/2025  Ingenieria vs Medicina -→  Futbol --→ 4-2  ");

        jLabel8.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 35, 102));
        jLabel8.setText("24/03/2025  Leo Pazcal vs Rafa Torres --→ Tenis --→  2-3");

        jLabel9.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 35, 102));
        jLabel9.setText("Ver más...");

        jLabel1.setText("INFORMACIÓN PERSONAL");

        jLabel4.setText("NOMBRES: Ana Sofia");

        jLabel5.setText("APELLIDOS: Ramos Granados ");

        jLabel10.setText("CARRERA: Ing.Sistemas");

        jLabel12.setText("ID: U00178255");

        jLabel13.setText("SEMESTRES CURSADOS: 3");

        javax.swing.GroupLayout infopanelLayout = new javax.swing.GroupLayout(infopanel);
        infopanel.setLayout(infopanelLayout);
        infopanelLayout.setHorizontalGroup(
            infopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, infopanelLayout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addGroup(infopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel12)
                    .addComponent(jLabel10)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4)
                    .addComponent(jLabel1))
                .addGap(33, 33, 33))
        );
        infopanelLayout.setVerticalGroup(
            infopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(infopanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout yopanelLayout = new javax.swing.GroupLayout(yopanel);
        yopanel.setLayout(yopanelLayout);
        yopanelLayout.setHorizontalGroup(
            yopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(yopanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(yo, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        yopanelLayout.setVerticalGroup(
            yopanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, yopanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(yo, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelarriba, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelabajo1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addComponent(GANADAS)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(PERDIDAS)
                .addGap(249, 249, 249))
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(72, 72, 72)
                                .addComponent(jLabel7))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(27, 27, 27)
                                .addComponent(jLabel9)))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(infopanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(161, 161, 161)
                                .addComponent(jLabel3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(yopanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(53, 53, 53))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelarriba, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(11, 11, 11)
                        .addComponent(yopanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(infopanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(GANADAS)
                    .addComponent(PERDIDAS))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel6))
                .addGap(40, 40, 40)
                .addComponent(panelabajo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lugaresbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lugaresbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lugaresbotonActionPerformed

    private void inicioboton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioboton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inicioboton2ActionPerformed

    private void deportesbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deportesbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deportesbotonActionPerformed

    private void estudiantesbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estudiantesbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_estudiantesbotonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new apunab().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel GANADAS;
    private javax.swing.JLabel PERDIDAS;
    private javax.swing.JLabel TEXTOO;
    private javax.swing.JLabel TEXTOO1;
    private javax.swing.JButton deportesboton;
    private javax.swing.JButton estudiantesboton;
    private javax.swing.JPanel infopanel;
    private javax.swing.JButton inicioboton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel logo3;
    private javax.swing.JLabel logo4;
    private javax.swing.JButton lugaresboton;
    private javax.swing.JPanel panelabajo;
    private javax.swing.JPanel panelabajo1;
    private javax.swing.JPanel panelarriba;
    private javax.swing.JLabel yo;
    private javax.swing.JPanel yopanel;
    // End of variables declaration//GEN-END:variables
}
