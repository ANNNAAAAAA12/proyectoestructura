
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Gyrcpro
 */
public class oscuro extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(oscuro.class.getName());

    /**
     * Creates new form oscuro
     */
    public oscuro() {
        initComponents();
        //letras
        texto1.setForeground(Color.WHITE);
        texto2.setForeground(Color.WHITE);
        texto3.setForeground(Color.WHITE);
        texto4.setForeground(Color.WHITE);
        
        //boton claro
        claro.addActionListener((ActionEvent e) -> {
    estudiantes ventanaEstudiantes = new estudiantes();
    ventanaEstudiantes.setVisible(true);
    dispose(); // Cierra la ventana actual
});
         lugaresboton.addActionListener((ActionEvent e) -> {
    lugares ventanaLugares = new lugares();
    ventanaLugares.setVisible(true);
    dispose(); // Cierra la ventana actual
});
         inicioboton2.addActionListener((ActionEvent e) -> {
    inicio ventanaInicio = new inicio();
    ventanaInicio.setVisible(true);
    dispose(); // Cierra la ventana actual
});
          deportesboton.addActionListener((ActionEvent e) -> {
    deportes ventanaDeportes = new deportes();
    ventanaDeportes.setVisible(true);
    dispose(); // Cierra la ventana actual
});
          apunabboton.addActionListener((ActionEvent e) -> {
    apunab ventanaApunab = new apunab();
    ventanaApunab.setVisible(true);
    dispose(); // Cierra la ventana actual
});
        getContentPane().setBackground(new java.awt.Color(0,0,0)); 
         panelarriba.setBackground(new java.awt.Color(0, 0, 14));
         panelabajo.setBackground(new java.awt.Color(0, 0, 14));
         //logoarribahp
        ImageIcon originalIcon = new ImageIcon(getClass().getResource("oscura.png"));
Image originalImage = originalIcon.getImage();
Image imagenEscalada = originalImage.getScaledInstance(200, 120, Image.SCALE_SMOOTH);
ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
logo = new javax.swing.JLabel(iconoEscalado);
//logoabajo
 ImageIcon originalIcon1 = new ImageIcon(getClass().getResource("logo2.png"));
Image originalImage1 = originalIcon1.getImage();

int nuevoAncho1 = 100;
int nuevoAlto1 = 100;
Image imagenEscalada1 = originalImage1.getScaledInstance(nuevoAncho1, nuevoAlto1, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado1 = new ImageIcon(imagenEscalada1);
logo3 = new javax.swing.JLabel(iconoEscalado1);

panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
panelabajo.add(logo3);
TEXTOO.setForeground(Color.WHITE);


//demaslogoarriba
lugaresboton.setBackground(new java.awt.Color(0,0,0));
        deportesboton.setBackground(new java.awt.Color(0,0,0));
        inicioboton2.setBackground(new java.awt.Color(0,0,0));
        apunabboton.setBackground(new java.awt.Color(0,0,0));
        lugaresboton.setBorder(BorderFactory.createEmptyBorder());
        deportesboton.setBorder(BorderFactory.createEmptyBorder());
        inicioboton2.setBorder(BorderFactory.createEmptyBorder());
        apunabboton.setBorder(BorderFactory.createEmptyBorder());
        lugaresboton.setForeground(Color.WHITE);
        deportesboton.setForeground(Color.WHITE);
        inicioboton2.setForeground(Color.WHITE);
        apunabboton.setForeground(Color.WHITE);
         lugaresboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         deportesboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         inicioboton2.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         apunabboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
JPanel panelBotones = new JPanel();
panelBotones.setBackground(new java.awt.Color(15, 175, 255)); // Igual que panelarriba
panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
panelBotones.setOpaque(false); 

// botones
panelBotones.add(Box.createHorizontalGlue());
panelBotones.add(lugaresboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(inicioboton2);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(deportesboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(apunabboton);
panelBotones.add(Box.createHorizontalGlue());

// panelarriba organizado con BorderLayout
panelarriba.setLayout(new BorderLayout());
panelarriba.removeAll(); // Limpiar 
panelarriba.add(logo, BorderLayout.WEST);          // Logo a la izquierda
panelarriba.add(panelBotones, BorderLayout.CENTER); // Botones centrados
panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT)); 

//anonimo
ImageIcon originalIcon3 = new ImageIcon(getClass().getResource("anonimo.png"));
Image originalImage3 = originalIcon3.getImage();

int nuevoAncho3 = 300;
int nuevoAlto3= 150;
Image imagenEscalada3 = originalImage3.getScaledInstance(nuevoAncho3, nuevoAlto3, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado3 = new ImageIcon(imagenEscalada3);
anonimo1 = new javax.swing.JLabel(iconoEscalado3);

anonimo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));
anonimo.add(anonimo1);

ImageIcon originalIcon4 = new ImageIcon(getClass().getResource("anonimo.png"));
Image originalImage4 = originalIcon4.getImage();

int nuevoAncho4 = 300;
int nuevoAlto4= 150;
Image imagenEscalada4 = originalImage4.getScaledInstance(nuevoAncho4, nuevoAlto4, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado4 = new ImageIcon(imagenEscalada4);
anonimo2 = new javax.swing.JLabel(iconoEscalado4);

anonimo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));
anonimo.add(anonimo2);

ImageIcon originalIcon5 = new ImageIcon(getClass().getResource("anonimo.png"));
Image originalImage5 = originalIcon5.getImage();

int nuevoAncho5 = 300;
int nuevoAlto5= 150;
Image imagenEscalada5 = originalImage5.getScaledInstance(nuevoAncho5, nuevoAlto5, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado5 = new ImageIcon(imagenEscalada5);
anonimo2 = new javax.swing.JLabel(iconoEscalado5);

anonimo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER));
anonimo.add(anonimo2);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelarriba = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        lugaresboton = new javax.swing.JButton();
        inicioboton2 = new javax.swing.JButton();
        deportesboton = new javax.swing.JButton();
        apunabboton = new javax.swing.JButton();
        panelabajo = new javax.swing.JPanel();
        TEXTOO = new javax.swing.JLabel();
        logo3 = new javax.swing.JLabel();
        anonimo = new javax.swing.JPanel();
        anonimo1 = new javax.swing.JLabel();
        anonimo3 = new javax.swing.JLabel();
        anonimo2 = new javax.swing.JLabel();
        texto1 = new javax.swing.JLabel();
        texto2 = new javax.swing.JLabel();
        texto3 = new javax.swing.JLabel();
        texto4 = new javax.swing.JLabel();
        claro = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lugaresboton.setText("lugares");
        lugaresboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lugaresbotonActionPerformed(evt);
            }
        });

        inicioboton2.setText("inicio");
        inicioboton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioboton2ActionPerformed(evt);
            }
        });

        deportesboton.setText("deportes");
        deportesboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deportesbotonActionPerformed(evt);
            }
        });

        apunabboton.setText("mis APUNAB");
        apunabboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apunabbotonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelarribaLayout = new javax.swing.GroupLayout(panelarriba);
        panelarriba.setLayout(panelarribaLayout);
        panelarribaLayout.setHorizontalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(164, 164, 164)
                .addComponent(lugaresboton)
                .addGap(114, 114, 114)
                .addComponent(inicioboton2)
                .addGap(109, 109, 109)
                .addComponent(deportesboton)
                .addGap(86, 86, 86)
                .addComponent(apunabboton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelarribaLayout.setVerticalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(27, 27, 27))
            .addGroup(panelarribaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lugaresboton)
                    .addComponent(inicioboton2)
                    .addComponent(deportesboton)
                    .addComponent(apunabboton))
                .addGap(120, 120, 120))
        );

        TEXTOO.setForeground(new java.awt.Color(18, 20, 9));
        TEXTOO.setText("ónoma de Bucaramanga, con domicilio en la ciudad de Bucaramanga, por 6 años. | Avenida 42 No. 48 – 11, Bucaramanga – Colombia. | PBX (57) (7) 643 6111/643 6261 | Cent");
        TEXTOO.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        TEXTOO.setAutoscrolls(true);

        javax.swing.GroupLayout panelabajoLayout = new javax.swing.GroupLayout(panelabajo);
        panelabajo.setLayout(panelabajoLayout);
        panelabajoLayout.setHorizontalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(TEXTOO, javax.swing.GroupLayout.PREFERRED_SIZE, 918, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(logo3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelabajoLayout.setVerticalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addGroup(panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(logo3, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                    .addGroup(panelabajoLayout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(TEXTOO)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout anonimoLayout = new javax.swing.GroupLayout(anonimo);
        anonimo.setLayout(anonimoLayout);
        anonimoLayout.setHorizontalGroup(
            anonimoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(anonimoLayout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addComponent(anonimo1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 419, Short.MAX_VALUE)
                .addComponent(anonimo3, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(87, 87, 87))
            .addGroup(anonimoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(anonimoLayout.createSequentialGroup()
                    .addGap(377, 377, 377)
                    .addComponent(anonimo2, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(420, Short.MAX_VALUE)))
        );
        anonimoLayout.setVerticalGroup(
            anonimoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(anonimoLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(anonimoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(anonimo1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(anonimo3, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(anonimoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, anonimoLayout.createSequentialGroup()
                    .addContainerGap(27, Short.MAX_VALUE)
                    .addComponent(anonimo2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(14, 14, 14)))
        );

        texto1.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        texto1.setForeground(new java.awt.Color(0, 35, 102));
        texto1.setText("Carlos Torres ( en racha 2 semestres 🔥​)");

        texto2.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        texto2.setForeground(new java.awt.Color(0, 35, 102));
        texto2.setText("Emiliana Rey");

        texto3.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        texto3.setForeground(new java.awt.Color(0, 35, 102));
        texto3.setText("Lorenzo mendieta");

        texto4.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        texto4.setForeground(new java.awt.Color(0, 35, 102));
        texto4.setText("ESTUDIANTES");

        claro.setText("modo claro");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelarriba, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelabajo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(texto1)
                        .addGap(93, 93, 93)
                        .addComponent(texto2)
                        .addGap(152, 152, 152)
                        .addComponent(texto3))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(claro)
                        .addGap(311, 311, 311)
                        .addComponent(texto4)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(33, 33, 33)
                    .addComponent(anonimo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(36, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelarriba, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(texto4)
                    .addComponent(claro))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 233, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(texto1)
                    .addComponent(texto2)
                    .addComponent(texto3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelabajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(144, 144, 144)
                    .addComponent(anonimo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(123, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lugaresbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lugaresbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lugaresbotonActionPerformed

    private void inicioboton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioboton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inicioboton2ActionPerformed

    private void deportesbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deportesbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deportesbotonActionPerformed

    private void apunabbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apunabbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apunabbotonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new oscuro().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TEXTOO;
    private javax.swing.JPanel anonimo;
    private javax.swing.JLabel anonimo1;
    private javax.swing.JLabel anonimo2;
    private javax.swing.JLabel anonimo3;
    private javax.swing.JButton apunabboton;
    private javax.swing.JButton claro;
    private javax.swing.JButton deportesboton;
    private javax.swing.JButton inicioboton2;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel logo3;
    private javax.swing.JButton lugaresboton;
    private javax.swing.JPanel panelabajo;
    private javax.swing.JPanel panelarriba;
    private javax.swing.JLabel texto1;
    private javax.swing.JLabel texto2;
    private javax.swing.JLabel texto3;
    private javax.swing.JLabel texto4;
    // End of variables declaration//GEN-END:variables
}
