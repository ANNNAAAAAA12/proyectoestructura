
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Gyrcpro
 */
public class ingles extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ingles.class.getName());

    /**
     * Creates new form ingles
     */
    public ingles() {
        initComponents();
        //boton funcion 
       lugaresboton.addActionListener((ActionEvent e) -> {
    lugares ventanaLugares = new lugares();
    ventanaLugares.setVisible(true);
    dispose(); // Cierra la ventana actual
});
       deportesboton.addActionListener((ActionEvent e) -> {
    deportes ventanaDeportes = new deportes();
    ventanaDeportes.setVisible(true);
    dispose(); // Cierra la ventana actual
});
      español.addActionListener((ActionEvent e) -> {
    inicio ventanaInicio = new inicio();
    ventanaInicio.setVisible(true);
    dispose(); // Cierra la ventana actual
});
       estudiantesboton.addActionListener((ActionEvent e) -> {
    estudiantes ventanaEstudiantes = new estudiantes();
    ventanaEstudiantes.setVisible(true);
    dispose(); // Cierra la ventana actual
});
       apunabboton.addActionListener((ActionEvent e) -> {
    apunab ventanaApunab = new apunab();
    ventanaApunab.setVisible(true);
    dispose(); // Cierra la ventana actual
});
       

        //coloresbotones
        lugaresboton.setBackground(new java.awt.Color(15,175,255));
        estudiantesboton.setBackground(new java.awt.Color(15, 175, 255));
        deportesboton.setBackground(new java.awt.Color(15, 175, 255));
        apunabboton.setBackground(new java.awt.Color(15, 175, 255));
        lugaresboton.setBorder(BorderFactory.createEmptyBorder());
        estudiantesboton.setBorder(BorderFactory.createEmptyBorder());
        deportesboton.setBorder(BorderFactory.createEmptyBorder());
        apunabboton.setBorder(BorderFactory.createEmptyBorder());
        lugaresboton.setForeground(Color.WHITE);
        estudiantesboton.setForeground(Color.WHITE);
        deportesboton.setForeground(Color.WHITE);
        apunabboton.setForeground(Color.WHITE);
         lugaresboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         estudiantesboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         deportesboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         apunabboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         
        
         getContentPane().setBackground(new java.awt.Color(106, 214, 218)); 
panelarriba.setBackground(new java.awt.Color(15, 175, 255));
panelabajo.setBackground(new java.awt.Color(114, 133, 140));
panelmitad.setBackground(new java.awt.Color(15, 175, 255));
TEXTOO.setForeground(Color.WHITE);
TITULO.setForeground(Color.WHITE);
TITULO.setBackground(new java.awt.Color(15, 175, 255));
TITULO.setBorder(BorderFactory.createEmptyBorder());
TITULO1.setForeground(Color.WHITE);
TITULO1.setBackground(new java.awt.Color(15, 175, 255));
TITULO1.setBorder(BorderFactory.createEmptyBorder());

// logoarribaizquieerda
ImageIcon originalIcon = new ImageIcon(getClass().getResource("logo.png"));
Image originalImage = originalIcon.getImage();
Image imagenEscalada = originalImage.getScaledInstance(200, 120, Image.SCALE_SMOOTH);
ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
logo = new javax.swing.JLabel(iconoEscalado);

// Logoabajo derecha
ImageIcon originalIcon1 = new ImageIcon(getClass().getResource("logo2.png"));
Image originalImage1 = originalIcon1.getImage();

int nuevoAncho1 = 100;
int nuevoAlto1 = 100;
Image imagenEscalada1 = originalImage1.getScaledInstance(nuevoAncho1, nuevoAlto1, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado1 = new ImageIcon(imagenEscalada1);
logo3 = new javax.swing.JLabel(iconoEscalado1);

panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
panelabajo.add(logo3);

//botones centrados
JPanel panelBotones = new JPanel();
panelBotones.setBackground(new java.awt.Color(15, 175, 255)); // Igual que panelarriba
panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
panelBotones.setOpaque(false); 

// botones
panelBotones.add(Box.createHorizontalGlue());
panelBotones.add(lugaresboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(deportesboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(estudiantesboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(apunabboton);
panelBotones.add(Box.createHorizontalGlue());

// panelarriba organizado con BorderLayout
panelarriba.setLayout(new BorderLayout());
panelarriba.removeAll(); // Limpiar cualquier contenido previo
panelarriba.add(logo, BorderLayout.WEST);          // Logo a la izquierda
panelarriba.add(panelBotones, BorderLayout.CENTER); // Botones centrados
panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));    
    }

    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelarriba = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        lugaresboton = new javax.swing.JButton();
        deportesboton = new javax.swing.JButton();
        estudiantesboton = new javax.swing.JButton();
        apunabboton = new javax.swing.JButton();
        panelabajo = new javax.swing.JPanel();
        TEXTOO = new javax.swing.JLabel();
        logo3 = new javax.swing.JLabel();
        panelmitad = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TITULO = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        TITULO1 = new javax.swing.JTextArea();
        español = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lugaresboton.setText("places");
        lugaresboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lugaresbotonActionPerformed(evt);
            }
        });

        deportesboton.setText("sports");
        deportesboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deportesbotonActionPerformed(evt);
            }
        });

        estudiantesboton.setText("students");
        estudiantesboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estudiantesbotonActionPerformed(evt);
            }
        });

        apunabboton.setText("mis APUNAB");
        apunabboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apunabbotonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelarribaLayout = new javax.swing.GroupLayout(panelarriba);
        panelarriba.setLayout(panelarribaLayout);
        panelarribaLayout.setHorizontalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 170, Short.MAX_VALUE)
                .addComponent(lugaresboton)
                .addGap(126, 126, 126)
                .addComponent(deportesboton)
                .addGap(103, 103, 103)
                .addComponent(estudiantesboton)
                .addGap(71, 71, 71)
                .addComponent(apunabboton)
                .addGap(42, 42, 42))
        );
        panelarribaLayout.setVerticalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelarribaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lugaresboton)
                    .addComponent(deportesboton)
                    .addComponent(estudiantesboton)
                    .addComponent(apunabboton))
                .addGap(50, 50, 50))
        );

        TEXTOO.setForeground(new java.awt.Color(18, 20, 9));
        TEXTOO.setText("ónoma de Bucaramanga, con domicilio en la ciudad de Bucaramanga, por 6 años. | Avenida 42 No. 48 – 11, Bucaramanga 643 6111/643 6261 | Cent");
        TEXTOO.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        TEXTOO.setAutoscrolls(true);

        javax.swing.GroupLayout panelabajoLayout = new javax.swing.GroupLayout(panelabajo);
        panelabajo.setLayout(panelabajoLayout);
        panelabajoLayout.setHorizontalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelabajoLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(TEXTOO, javax.swing.GroupLayout.PREFERRED_SIZE, 782, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logo3, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        panelabajoLayout.setVerticalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logo3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(TEXTOO)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        TITULO.setColumns(20);
        TITULO.setFont(new java.awt.Font("Gloucester MT Extra Condensed", 1, 24)); // NOI18N
        TITULO.setLineWrap(true);
        TITULO.setRows(5);
        TITULO.setText("\n\n              How can I bet?");
        TITULO.setToolTipText("");
        TITULO.setWrapStyleWord(true);
        jScrollPane1.setViewportView(TITULO);

        TITULO1.setColumns(20);
        TITULO1.setFont(new java.awt.Font("Franklin Gothic Book", 0, 12)); // NOI18N
        TITULO1.setLineWrap(true);
        TITULO1.setRows(5);
        TITULO1.setText("                                            in person : \n\n1. Visit a place verified by the institution. If you're not sure, click here.\n\n2. Show your UNAB ID card.\n\n3. Place your bet.\n\n                                             virtual: \n\n                                  Press \"sports\"");
        TITULO1.setToolTipText("");
        TITULO1.setWrapStyleWord(true);
        jScrollPane2.setViewportView(TITULO1);

        español.setText("translate");

        javax.swing.GroupLayout panelmitadLayout = new javax.swing.GroupLayout(panelmitad);
        panelmitad.setLayout(panelmitadLayout);
        panelmitadLayout.setHorizontalGroup(
            panelmitadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelmitadLayout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 235, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 316, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(español)
                .addGap(34, 34, 34))
        );
        panelmitadLayout.setVerticalGroup(
            panelmitadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelmitadLayout.createSequentialGroup()
                .addGroup(panelmitadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelmitadLayout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelmitadLayout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelmitadLayout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addComponent(español)))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelarriba, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelabajo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(panelmitad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelarriba, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 294, Short.MAX_VALUE)
                .addComponent(panelabajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(158, 158, 158)
                    .addComponent(panelmitad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(165, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lugaresbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lugaresbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lugaresbotonActionPerformed

    private void deportesbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deportesbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deportesbotonActionPerformed

    private void estudiantesbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estudiantesbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_estudiantesbotonActionPerformed

    private void apunabbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apunabbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apunabbotonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ingles().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TEXTOO;
    private javax.swing.JTextArea TITULO;
    private javax.swing.JTextArea TITULO1;
    private javax.swing.JButton apunabboton;
    private javax.swing.JButton deportesboton;
    private javax.swing.JButton español;
    private javax.swing.JButton estudiantesboton;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel logo3;
    private javax.swing.JButton lugaresboton;
    private javax.swing.JPanel panelabajo;
    private javax.swing.JPanel panelarriba;
    private javax.swing.JPanel panelmitad;
    // End of variables declaration//GEN-END:variables
}
