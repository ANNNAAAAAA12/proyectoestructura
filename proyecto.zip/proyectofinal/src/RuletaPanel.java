import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class RuletaPanel extends JPanel {
    private int porcentajeAzul = 70;

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        int width = getWidth();
        int height = getHeight();
        int size = Math.min(width, height) - 20;

        int x = (width - size) / 2;
        int y = (height - size) / 2;

        // Ángulos de los porcentajes
        int anguloAzul = (int) (360 * (porcentajeAzul / 100.0));
        int anguloRojo = 360 - anguloAzul;

        // Dibujar azul
        g2.setColor(Color.BLUE);
        g2.fillArc(x, y, size, size, 0, anguloAzul);

        // Dibujar rojo
        g2.setColor(Color.RED);
        g2.fillArc(x, y, size, size, anguloAzul, anguloRojo);
    }
}
