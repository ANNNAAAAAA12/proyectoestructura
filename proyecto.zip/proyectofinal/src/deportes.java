
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Gyrcpro
 */
public class deportes extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(deportes.class.getName());

    /**
     * Creates new form deportes
     */
    public deportes() {
        initComponents();
        //botones funcion
         lugaresboton.addActionListener((ActionEvent e) -> {
    lugares ventanaLugares = new lugares();
    ventanaLugares.setVisible(true);
    dispose(); // Cierra la ventana actual
});
         apunabboton.addActionListener((ActionEvent e) -> {
    apunab ventanaApunab = new apunab();
    ventanaApunab.setVisible(true);
    dispose(); // Cierra la ventana actual
});
         inicioboton2.addActionListener((ActionEvent e) -> {
    inicio ventanaInicio = new inicio();
    ventanaInicio.setVisible(true);
    dispose(); // Cierra la ventana actual
});
         VER.addActionListener(e -> {
    VER ventanaVER = new VER();
    ventanaVER.setVisible(true);
    dispose();
});
         estudiantesboton.addActionListener((ActionEvent e) -> {
    estudiantes ventanaEstudiantes = new estudiantes();
    ventanaEstudiantes.setVisible(true);
    dispose(); // Cierra la ventana actual
});
         //basicooooo
        getContentPane().setBackground(new java.awt.Color(106, 214, 218)); 
         panelarriba.setBackground(new java.awt.Color(15, 175, 255));
         panelabajo.setBackground(new java.awt.Color(114, 133, 140));
         //logoarribahp
        ImageIcon originalIcon = new ImageIcon(getClass().getResource("logo.png"));
Image originalImage = originalIcon.getImage();
Image imagenEscalada = originalImage.getScaledInstance(200, 120, Image.SCALE_SMOOTH);
ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
logo = new javax.swing.JLabel(iconoEscalado);
//logoabajo
 ImageIcon originalIcon1 = new ImageIcon(getClass().getResource("logo2.png"));
Image originalImage1 = originalIcon1.getImage();

int nuevoAncho1 = 100;
int nuevoAlto1 = 100;
Image imagenEscalada1 = originalImage1.getScaledInstance(nuevoAncho1, nuevoAlto1, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado1 = new ImageIcon(imagenEscalada1);
logo3 = new javax.swing.JLabel(iconoEscalado1);

panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
panelabajo.add(logo3);
TEXTOO.setForeground(Color.WHITE);


//demaslogoarriba
lugaresboton.setBackground(new java.awt.Color(15,175,255));
        estudiantesboton.setBackground(new java.awt.Color(15, 175, 255));
        inicioboton2.setBackground(new java.awt.Color(15, 175, 255));
        apunabboton.setBackground(new java.awt.Color(15, 175, 255));
        lugaresboton.setBorder(BorderFactory.createEmptyBorder());
        estudiantesboton.setBorder(BorderFactory.createEmptyBorder());
        inicioboton2.setBorder(BorderFactory.createEmptyBorder());
        apunabboton.setBorder(BorderFactory.createEmptyBorder());
        lugaresboton.setForeground(Color.WHITE);
        estudiantesboton.setForeground(Color.WHITE);
        inicioboton2.setForeground(Color.WHITE);
        apunabboton.setForeground(Color.WHITE);
         lugaresboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         estudiantesboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         inicioboton2.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         apunabboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
JPanel panelBotones = new JPanel();
panelBotones.setBackground(new java.awt.Color(15, 175, 255)); // Igual que panelarriba
panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
panelBotones.setOpaque(false); // Asegura que no sobrescriba el fondo si hay algún error

// botones
panelBotones.add(Box.createHorizontalGlue());
panelBotones.add(lugaresboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(inicioboton2);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(estudiantesboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(apunabboton);
panelBotones.add(Box.createHorizontalGlue());

// panelarriba organizado con BorderLayout
panelarriba.setLayout(new BorderLayout());
panelarriba.removeAll(); // Limpiar 
panelarriba.add(logo, BorderLayout.WEST);          // Logo a la izquierda
panelarriba.add(panelBotones, BorderLayout.CENTER); // Botones centrados
panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT)); 
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jMenu2 = new javax.swing.JMenu();
        panelarriba = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        lugaresboton = new javax.swing.JButton();
        inicioboton2 = new javax.swing.JButton();
        estudiantesboton = new javax.swing.JButton();
        apunabboton = new javax.swing.JButton();
        panelabajo = new javax.swing.JPanel();
        TEXTOO = new javax.swing.JLabel();
        logo3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        VER = new javax.swing.JButton();

        jMenu1.setText("jMenu1");

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        jMenu2.setText("jMenu2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lugaresboton.setText("lugares");
        lugaresboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lugaresbotonActionPerformed(evt);
            }
        });

        inicioboton2.setText("inicio");
        inicioboton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioboton2ActionPerformed(evt);
            }
        });

        estudiantesboton.setText("estudiantes");
        estudiantesboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estudiantesbotonActionPerformed(evt);
            }
        });

        apunabboton.setText("mis APUNAB");
        apunabboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apunabbotonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelarribaLayout = new javax.swing.GroupLayout(panelarriba);
        panelarriba.setLayout(panelarribaLayout);
        panelarribaLayout.setHorizontalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lugaresboton)
                .addGap(126, 126, 126)
                .addComponent(inicioboton2)
                .addGap(103, 103, 103)
                .addComponent(estudiantesboton)
                .addGap(71, 71, 71)
                .addComponent(apunabboton)
                .addGap(42, 42, 42))
        );
        panelarribaLayout.setVerticalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelarribaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lugaresboton)
                    .addComponent(inicioboton2)
                    .addComponent(estudiantesboton)
                    .addComponent(apunabboton))
                .addGap(50, 50, 50))
        );

        TEXTOO.setForeground(new java.awt.Color(18, 20, 9));
        TEXTOO.setText("ónoma de Bucaramanga, con domicilio en la ciudad de Bucaramanga, por 6 años. | Avenida 42 No. 48 – 11, Bucaramanga – Colombia. | PBX (57) (7) 643 6111/643 6261 | Cent");
        TEXTOO.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        TEXTOO.setAutoscrolls(true);

        javax.swing.GroupLayout panelabajoLayout = new javax.swing.GroupLayout(panelabajo);
        panelabajo.setLayout(panelabajoLayout);
        panelabajoLayout.setHorizontalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TEXTOO, javax.swing.GroupLayout.PREFERRED_SIZE, 918, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(logo3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(66, Short.MAX_VALUE))
        );
        panelabajoLayout.setVerticalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addComponent(logo3, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(TEXTOO)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 35, 102));
        jLabel1.setText("DEPORTES");

        jLabel2.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 35, 102));
        jLabel2.setText("Fútbol  ⚽");

        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 35, 102));
        jLabel3.setText("Tenis 🥎​");

        jLabel4.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 35, 102));
        jLabel4.setText("Volley 🏐​");

        jLabel5.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 35, 102));
        jLabel5.setText("Basket 🏀​");

        jLabel6.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 35, 102));
        jLabel6.setText("partidos en tendencia  🔥​                     todos los partidos                                 jugadores           ");

        jLabel7.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 35, 102));
        jLabel7.setText("partidos en tendencia  🔥​                      todos los partidos                                 jugadores           ");

        jLabel8.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 35, 102));
        jLabel8.setText("partidos en tendencia  🔥​                      todos los partidos                                 jugadores           ");

        jLabel9.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 35, 102));
        jLabel9.setText("partidos en tendencia  🔥​                      todos los partidos                                 jugadores           ");

        VER.setText("VER");
        VER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VERActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelarriba, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelabajo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(473, 473, 473)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(102, 102, 102))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel4)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addGap(18, 18, 18)
                                            .addComponent(VER)))
                                    .addGap(12, 12, 12)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(107, 107, 107)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7)
                            .addComponent(jLabel9)
                            .addComponent(jLabel6))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelarriba, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel6)
                    .addComponent(VER))
                .addGap(67, 67, 67)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel4))
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel5))
                .addGap(28, 28, 28)
                .addComponent(panelabajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lugaresbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lugaresbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lugaresbotonActionPerformed

    private void inicioboton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioboton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inicioboton2ActionPerformed

    private void estudiantesbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estudiantesbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_estudiantesbotonActionPerformed

    private void apunabbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apunabbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apunabbotonActionPerformed

    private void VERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VERActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_VERActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new deportes().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TEXTOO;
    private javax.swing.JButton VER;
    private javax.swing.JButton apunabboton;
    private javax.swing.JButton estudiantesboton;
    private javax.swing.JButton inicioboton2;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel logo3;
    private javax.swing.JButton lugaresboton;
    private javax.swing.JPanel panelabajo;
    private javax.swing.JPanel panelarriba;
    // End of variables declaration//GEN-END:variables
}
