
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author Gyrcpro
 */
public class lugares extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(lugares.class.getName());

    /**
     * Creates new form lugares
     */
    public lugares() {
        initComponents();
        //botones funconan
        inicioboton2.addActionListener((ActionEvent e) -> {
    inicio ventanaInicio = new inicio();
    ventanaInicio.setVisible(true);
    dispose(); // Cierra la ventana actual
});
        deportesboton.addActionListener((ActionEvent e) -> {
    deportes ventanaDeportes = new deportes(); // Instanciar la ventana
    ventanaDeportes.setVisible(true);          // Mostrarla
    dispose();                                 // Cerrar la actual
});
        estudiantesboton.addActionListener((ActionEvent e) -> {
    estudiantes ventanaEstudiantes = new estudiantes();
    ventanaEstudiantes.setVisible(true);
    dispose(); // Cierra la ventana actual
});
        apunabboton.addActionListener((ActionEvent e) -> {
    apunab ventanaApunab = new apunab();
    ventanaApunab.setVisible(true);
    dispose(); // Cierra la ventana actual
});
        //basicooooo
        getContentPane().setBackground(new java.awt.Color(106, 214, 218)); 
         panelarriba.setBackground(new java.awt.Color(15, 175, 255));
         panelabajo.setBackground(new java.awt.Color(114, 133, 140));
         //logoarribahp
        ImageIcon originalIcon = new ImageIcon(getClass().getResource("logo.png"));
Image originalImage = originalIcon.getImage();
Image imagenEscalada = originalImage.getScaledInstance(200, 120, Image.SCALE_SMOOTH);
ImageIcon iconoEscalado = new ImageIcon(imagenEscalada);
logo = new javax.swing.JLabel(iconoEscalado);
//logoabajo
 ImageIcon originalIcon1 = new ImageIcon(getClass().getResource("logo2.png"));
Image originalImage1 = originalIcon1.getImage();

int nuevoAncho1 = 100;
int nuevoAlto1 = 100;
Image imagenEscalada1 = originalImage1.getScaledInstance(nuevoAncho1, nuevoAlto1, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado1 = new ImageIcon(imagenEscalada1);
logo3 = new javax.swing.JLabel(iconoEscalado1);

panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));
panelabajo.add(logo3);
TEXTOO.setForeground(Color.WHITE);


//demaslogoarriba
inicioboton2.setBackground(new java.awt.Color(15,175,255));
        estudiantesboton.setBackground(new java.awt.Color(15, 175, 255));
        deportesboton.setBackground(new java.awt.Color(15, 175, 255));
        apunabboton.setBackground(new java.awt.Color(15, 175, 255));
        inicioboton2.setBorder(BorderFactory.createEmptyBorder());
        estudiantesboton.setBorder(BorderFactory.createEmptyBorder());
        deportesboton.setBorder(BorderFactory.createEmptyBorder());
        apunabboton.setBorder(BorderFactory.createEmptyBorder());
        inicioboton2.setForeground(Color.WHITE);
        estudiantesboton.setForeground(Color.WHITE);
        deportesboton.setForeground(Color.WHITE);
        apunabboton.setForeground(Color.WHITE);
         inicioboton2.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         estudiantesboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         deportesboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
         apunabboton.setFont(new Font("KyivType Sans", Font.PLAIN, 19));
JPanel panelBotones = new JPanel();
panelBotones.setBackground(new java.awt.Color(15, 175, 255)); // Igual que panelarriba
panelBotones.setLayout(new BoxLayout(panelBotones, BoxLayout.X_AXIS));
panelBotones.setOpaque(false); // Asegura que no sobrescriba el fondo si hay algún error

// botones
panelBotones.add(Box.createHorizontalGlue());
panelBotones.add(inicioboton2);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(deportesboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(estudiantesboton);
panelBotones.add(Box.createHorizontalStrut(20));
panelBotones.add(apunabboton);
panelBotones.add(Box.createHorizontalGlue());

// panelarriba organizado con BorderLayout
panelarriba.setLayout(new BorderLayout());
panelarriba.removeAll(); // Limpiar 
panelarriba.add(logo, BorderLayout.WEST);          // Logo a la izquierda
panelarriba.add(panelBotones, BorderLayout.CENTER); // Botones centrados
panelabajo.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));    
    //panelfoto
     ImageIcon originalIcon2 = new ImageIcon(getClass().getResource("foto.png"));
Image originalImage2 = originalIcon2.getImage();

int nuevoAncho2 = 200;
int nuevoAlto2 = 200;
Image imagenEscalada2 = originalImage2.getScaledInstance(nuevoAncho2, nuevoAlto2, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado2 = new ImageIcon(imagenEscalada2);
foto = new javax.swing.JLabel(iconoEscalado2);

panelfoto.setLayout(new java.awt.FlowLayout());
panelfoto.add(foto);

ImageIcon originalIcon3 = new ImageIcon(getClass().getResource("foto1.png"));
Image originalImage3 = originalIcon3.getImage();

int nuevoAncho3 = 300;
int nuevoAlto3 = 200;
Image imagenEscalada3 = originalImage3.getScaledInstance(nuevoAncho3, nuevoAlto3, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado3 = new ImageIcon(imagenEscalada3);
foto1 = new javax.swing.JLabel(iconoEscalado3);

panelfoto1.setLayout(new java.awt.FlowLayout());
panelfoto1.add(foto1);

ImageIcon originalIcon4 = new ImageIcon(getClass().getResource("foto2.png"));
Image originalImage4 = originalIcon4.getImage();

int nuevoAncho4 = 200;
int nuevoAlto4 = 200;
Image imagenEscalada4 = originalImage4.getScaledInstance(nuevoAncho4, nuevoAlto4, Image.SCALE_SMOOTH);

ImageIcon iconoEscalado4 = new ImageIcon(imagenEscalada4);
foto2 = new javax.swing.JLabel(iconoEscalado4);

panelfoto2.setLayout(new java.awt.FlowLayout());
panelfoto2.add(foto2);


    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        panelarriba = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        inicioboton2 = new javax.swing.JButton();
        deportesboton = new javax.swing.JButton();
        estudiantesboton = new javax.swing.JButton();
        apunabboton = new javax.swing.JButton();
        panelabajo = new javax.swing.JPanel();
        TEXTOO = new javax.swing.JLabel();
        logo3 = new javax.swing.JLabel();
        panelfoto = new javax.swing.JPanel();
        foto = new javax.swing.JLabel();
        panelfoto2 = new javax.swing.JPanel();
        foto2 = new javax.swing.JLabel();
        panelfoto1 = new javax.swing.JPanel();
        foto1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        jScrollPane1.setViewportView(jTextPane1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        inicioboton2.setText("inicio");
        inicioboton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inicioboton2ActionPerformed(evt);
            }
        });

        deportesboton.setText("deportes");
        deportesboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deportesbotonActionPerformed(evt);
            }
        });

        estudiantesboton.setText("estudiantes");
        estudiantesboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estudiantesbotonActionPerformed(evt);
            }
        });

        apunabboton.setText("mis APUNAB");
        apunabboton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apunabbotonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelarribaLayout = new javax.swing.GroupLayout(panelarriba);
        panelarriba.setLayout(panelarribaLayout);
        panelarribaLayout.setHorizontalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelarribaLayout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(inicioboton2)
                .addGap(167, 167, 167)
                .addComponent(deportesboton)
                .addGap(141, 141, 141)
                .addComponent(estudiantesboton)
                .addGap(127, 127, 127)
                .addComponent(apunabboton)
                .addGap(111, 111, 111))
        );
        panelarribaLayout.setVerticalGroup(
            panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelarribaLayout.createSequentialGroup()
                .addGroup(panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(logo, javax.swing.GroupLayout.DEFAULT_SIZE, 121, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelarribaLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(panelarribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(inicioboton2)
                            .addComponent(deportesboton)
                            .addComponent(estudiantesboton)
                            .addComponent(apunabboton))
                        .addGap(59, 59, 59)))
                .addContainerGap())
        );

        TEXTOO.setForeground(new java.awt.Color(18, 20, 9));
        TEXTOO.setText("ónoma de Bucaramanga, con domicilio en la ciudad de Bucaramanga, por 6 años. | Avenida 42 No. 48 – 11, Bucaramanga – Colombia. | PBX (57) (7) 643 6111/643 6261 | Cent");
        TEXTOO.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        TEXTOO.setAutoscrolls(true);

        javax.swing.GroupLayout panelabajoLayout = new javax.swing.GroupLayout(panelabajo);
        panelabajo.setLayout(panelabajoLayout);
        panelabajoLayout.setHorizontalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(TEXTOO, javax.swing.GroupLayout.PREFERRED_SIZE, 918, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logo3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58))
        );
        panelabajoLayout.setVerticalGroup(
            panelabajoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addComponent(logo3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(panelabajoLayout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(TEXTOO)
                .addGap(56, 56, 56))
        );

        javax.swing.GroupLayout panelfotoLayout = new javax.swing.GroupLayout(panelfoto);
        panelfoto.setLayout(panelfotoLayout);
        panelfotoLayout.setHorizontalGroup(
            panelfotoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelfotoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(foto, javax.swing.GroupLayout.DEFAULT_SIZE, 302, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelfotoLayout.setVerticalGroup(
            panelfotoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelfotoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(foto, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout panelfoto2Layout = new javax.swing.GroupLayout(panelfoto2);
        panelfoto2.setLayout(panelfoto2Layout);
        panelfoto2Layout.setHorizontalGroup(
            panelfoto2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelfoto2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(foto2, javax.swing.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE)
                .addGap(23, 23, 23))
        );
        panelfoto2Layout.setVerticalGroup(
            panelfoto2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelfoto2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(foto2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout panelfoto1Layout = new javax.swing.GroupLayout(panelfoto1);
        panelfoto1.setLayout(panelfoto1Layout);
        panelfoto1Layout.setHorizontalGroup(
            panelfoto1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelfoto1Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addComponent(foto1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(48, 48, 48))
        );
        panelfoto1Layout.setVerticalGroup(
            panelfoto1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelfoto1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(foto1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 35, 102));
        jLabel1.setText("LUGARES APUNAB");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelarriba, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(panelabajo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addComponent(panelfoto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addComponent(panelfoto1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95)
                .addComponent(panelfoto2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46))
            .addGroup(layout.createSequentialGroup()
                .addGap(512, 512, 512)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelarriba, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(jLabel1)
                .addGap(68, 68, 68)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelfoto2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelfoto1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(panelfoto, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 39, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelabajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void inicioboton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inicioboton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inicioboton2ActionPerformed

    private void deportesbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deportesbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deportesbotonActionPerformed

    private void estudiantesbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estudiantesbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_estudiantesbotonActionPerformed

    private void apunabbotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apunabbotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apunabbotonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new lugares().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TEXTOO;
    private javax.swing.JButton apunabboton;
    private javax.swing.JButton deportesboton;
    private javax.swing.JButton estudiantesboton;
    private javax.swing.JLabel foto;
    private javax.swing.JLabel foto1;
    private javax.swing.JLabel foto2;
    private javax.swing.JButton inicioboton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JLabel logo;
    private javax.swing.JLabel logo3;
    private javax.swing.JPanel panelabajo;
    private javax.swing.JPanel panelarriba;
    private javax.swing.JPanel panelfoto;
    private javax.swing.JPanel panelfoto1;
    private javax.swing.JPanel panelfoto2;
    // End of variables declaration//GEN-END:variables
}
